package com.example.lab7;

import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentActivity;

import android.Manifest;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback,
        GoogleMap.OnMapLoadedCallback,
        GoogleMap.OnMarkerClickListener,
        GoogleMap.OnMapLongClickListener,
        SensorEventListener {

    private static final int MY_PERMISSION_REQUEST_ACCESS_FINE_LOCATION = 101;
    //aktualnie załadowana mapa
    private GoogleMap mMap;
    //zapewnia dostęp do funkcji lokalizacji
    private FusedLocationProviderClient fusedLocationClient;
    /*
    //dostarcza uaktualnienia lokalizacji z funkcji lokalizacji
    private LocationRequest mLocationRequest;
    //obsługuje uaktualnienia lokalizacji
    private LocationCallback locationCallback;
    //pokazuje aktualną pozycję urządzenia
    Marker gpsMarker = null;
     */

    List<Marker> markerList;
    List<LatLng> markerPosition;

    static public SensorManager mSensorManager;
    //Lista aktywnych sensorów
    static Sensor mSensor;

    FloatingActionButton f_o;
    FloatingActionButton f_x;
    AnimatorSet animatorSet = new AnimatorSet();
    AnimatorSet animatorSet2 = new AnimatorSet();

    private final String TASKS_JSON_FILE = "tasks.json";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mSensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        mSensor = mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

        setContentView(R.layout.activity_main);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        markerList = new ArrayList<>();
        markerPosition = new ArrayList<>();

        f_o = findViewById(R.id.fABO);
        f_x = findViewById(R.id.fABX);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        mMap.setOnMapLoadedCallback(this);
        mMap.setOnMarkerClickListener(this);
        mMap.setOnMapLongClickListener(this);
    }

    @Override
    public void onMapLoaded() {
        Log.i(MapsActivity.class.getSimpleName(),"MapLoaded");
        if(ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},MY_PERMISSION_REQUEST_ACCESS_FINE_LOCATION);
            return;
        }
        restoreFromJson();
    }

    @Override
    public void onMapLongClick(LatLng latLng) {
        Marker marker = mMap.addMarker(new MarkerOptions()
                .position(new LatLng(latLng.latitude,latLng.longitude))
                .alpha(0.8f)
                .title(String.format("Position: (%.2f, %.2f)",latLng.latitude, latLng.longitude)));
        markerList.add(marker);
        markerPosition.add(marker.getPosition());
    }

    @Override
    public boolean onMarkerClick(Marker marker) {
        f_o.setVisibility(View.VISIBLE);
        f_x.setVisibility(View.VISIBLE);

        ObjectAnimator buttonO = ObjectAnimator.ofFloat(f_o,"translationY",250f, -50f);
        buttonO.setDuration(1000);
        ObjectAnimator buttonX = ObjectAnimator.ofFloat(f_x,"translationY",250f, -50f);
        buttonX.setDuration(1000);

        animatorSet.play(buttonO).with(buttonX);
        animatorSet.start();

        return false;
    }

    public void exit(View view) {
        ObjectAnimator buttonO2 = ObjectAnimator.ofFloat(f_o,"translationY",-50f, 250f);
        buttonO2.setDuration(1000);
        ObjectAnimator buttonX2 = ObjectAnimator.ofFloat(f_x,"translationY",-50f, 250f);
        buttonX2.setDuration(1000);

        animatorSet2.play(buttonO2).with(buttonX2);
        animatorSet2.start();

        TextView text = findViewById(R.id.acceleration);
        text.setVisibility(View.INVISIBLE);
    }

    public void enter(View view) {
        TextView text = findViewById(R.id.acceleration);
        text.setVisibility(View.VISIBLE);
    }

    public void zoomOutClick(View view) {
        mMap.moveCamera(CameraUpdateFactory.zoomOut());
    }

    public void zoomInClick(View view) {
        mMap.moveCamera(CameraUpdateFactory.zoomIn());
    }

    public void clearMemory() throws JSONException {
        JSONArray jsonArray = new JSONArray();
        JSONObject jsonMarkers = new JSONObject();
        jsonMarkers.put("jsonArray",jsonArray);
        try{
            //FileOutputStream overWrite = new FileOutputStream(TASKS_JSON_FILE,false);
            FileWriter writer = new FileWriter(TASKS_JSON_FILE,false);
            writer.write(jsonMarkers.toString());
            writer.close();
        }catch(FileNotFoundException e){
            e.printStackTrace();
        }catch(IOException e){
            e.printStackTrace();
        }

        mMap.clear();
        markerList.clear();
        markerPosition.clear();
    }

    //SENSOR
    @Override
    public void onSensorChanged(SensorEvent event) {
        StringBuilder stringBuilder = new StringBuilder();
        for(int i = 0; i < 2; i++){
            stringBuilder.append(String.format("Val[%d]=%.4f ",i,event.values[i]));
        }
        TextView valueTextView = findViewById(R.id.acceleration);
        valueTextView.setText("Acceleration:\n" + stringBuilder.toString());
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    @Override
    protected void onResume(){
        super.onResume();
        if(mSensor != null)
            mSensorManager.registerListener((SensorEventListener) this,mSensor, SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    protected void onPause(){
        super.onPause();
        //wyłączenie sensora, gdy nie jest używany
        if(mSensor != null)
            mSensorManager.unregisterListener((SensorEventListener) this,mSensor);
    }

    //STORAGE
    private void saveTasksToJson(){
        Gson gson = new Gson();
        String listJson = gson.toJson(markerPosition);
        FileOutputStream outputStream;
        try{
            outputStream = openFileOutput(TASKS_JSON_FILE,MODE_PRIVATE);
            FileWriter writer = new FileWriter(outputStream.getFD());
            writer.write(listJson);
            writer.close();
        }catch(FileNotFoundException e){
            e.printStackTrace();
        }catch(IOException e){
            e.printStackTrace();
        }
    }

    public void restoreFromJson(){
        FileInputStream inputStream;
        int DEFAULT_BUFFER_SIZE = 10000;
        Gson gson = new Gson();
        String readJson;

        try{
            inputStream = openFileInput(TASKS_JSON_FILE);
            FileReader reader = new FileReader(inputStream.getFD());
            char[] buf = new char[DEFAULT_BUFFER_SIZE];
            int n;
            StringBuilder builder = new StringBuilder();
            while((n = reader.read(buf)) >= 0){
                String tmp = String.valueOf(buf);
                String substring = (n<DEFAULT_BUFFER_SIZE) ? tmp.substring(0,n) : tmp;
                builder.append(substring);
            }
            reader.close();
            readJson = builder.toString();
            Type collectionType = new TypeToken<List<LatLng>>(){
            }.getType();
            List<LatLng> o = gson.fromJson(readJson,collectionType);
            if(o != null){
                markerList.clear();
                for(LatLng task : o){
                    Marker marker = mMap.addMarker(new MarkerOptions()
                            .position(new LatLng(task.latitude,task.longitude))
                            .alpha(0.8f)
                            .title(String.format("Position: (%.2f, %.2f)",task.latitude, task.longitude)));
                    markerList.add(marker);
                    markerPosition.add(marker.getPosition());
                }
            }
        }catch(FileNotFoundException e){
            e.printStackTrace();
        }catch (IOException e){
            e.printStackTrace();
        }
    }

    @Override
    protected void onDestroy() {
        saveTasksToJson();
        super.onDestroy();
    }
}
